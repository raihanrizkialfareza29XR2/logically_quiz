<?php

$no = [1, 2, 6];

$max = max($no);


for($i=0; $i < count($no); $i++){
    echo 'input = ' . $no[$i]."<br>";
}
echo 'terbesar : ' . $max;

?>